import { useState, useEffect } from 'react';
import FileAnalyzer from './components/FileAnalyzer';
import ArcadeGame from './components/ArcadeGame';
import DinoGame from './components/DinoGame';
import FlappyBirdGame from './components/FlappyBirdGame';
import SnakeGame from './components/SnakeGame';
import BreakoutGame from './components/BreakoutGame';
import PongGame from './components/PongGame';
import TetrisGame from './components/TetrisGame';
import { Question, Difficulty } from './utils/questionExtractor';
import { Trophy, Gamepad2, Play, BookOpen, Sun, Moon } from 'lucide-react';

type GameType = 'SPACE' | 'DINO' | 'FLAPPY' | 'SNAKE' | 'BREAKOUT' | 'PONG' | 'TETRIS';

interface GameOption {
  id: GameType;
  name: string;
  emoji: string;
  description: string;
}

const GAMES: GameOption[] = [
  { id: 'SPACE', name: 'Uzay Macerası', emoji: '🚀', description: 'Asteroidleri vur' },
  { id: 'DINO', name: 'Dinozor Koşusu', emoji: '🦖', description: 'Engelleri zıpla' },
  { id: 'FLAPPY', name: 'Kanatlı Kuş', emoji: '🐦', description: 'Borulardan geç' },
  { id: 'SNAKE', name: 'Yılan Oyunu', emoji: '🐍', description: 'Yemleri topla' },
  { id: 'BREAKOUT', name: 'Tuğla Kırma', emoji: '🧱', description: 'Tuğlaları yık' },
  { id: 'PONG', name: 'Pong', emoji: '🏓', description: 'Rakibi yen' },
  { id: 'TETRIS', name: 'Tetris', emoji: '🧩', description: 'Satır tamamla' },
];

const GAME_COLORS: Record<GameType, string> = {
  SPACE: 'from-indigo-600 to-purple-600',
  DINO: 'from-amber-500 to-orange-600',
  FLAPPY: 'from-emerald-500 to-teal-600',
  SNAKE: 'from-lime-500 to-green-600',
  BREAKOUT: 'from-rose-500 to-red-600',
  PONG: 'from-sky-500 to-blue-600',
  TETRIS: 'from-purple-500 to-violet-600',
};

const INITIAL_HIGH_SCORES: Record<GameType, number> = {
  SPACE: 0, DINO: 0, FLAPPY: 0, SNAKE: 0, BREAKOUT: 0, PONG: 0, TETRIS: 0
};

export default function App() {
  const [view, setView] = useState<'ANALYZE' | 'GAME'>('ANALYZE');
  const [gameType, setGameType] = useState<GameType>('SPACE');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [difficulty, setDifficulty] = useState<Difficulty>('NORMAL');
  const [highScores, setHighScores] = useState<Record<GameType, number>>(() => {
    try {
      const saved = localStorage.getItem('eduplay_highscores_v2');
      if (saved) return { ...INITIAL_HIGH_SCORES, ...JSON.parse(saved) };
    } catch {}
    return INITIAL_HIGH_SCORES;
  });

  useEffect(() => {
    try {
      localStorage.setItem('eduplay_highscores_v2', JSON.stringify(highScores));
    } catch {}
  }, [highScores]);

  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('eduplay_theme') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    if (theme === 'light') {
      document.body.classList.add('light-theme');
    } else {
      document.body.classList.remove('light-theme');
    }
    localStorage.setItem('eduplay_theme', theme);
  }, [theme]);

  const handleSetHighScore = (gameType: GameType) => (newScore: number) => {
    setHighScores(prev => ({
      ...prev,
      [gameType]: Math.max(prev[gameType], newScore)
    }));
  };

  const totalHighScore = Object.values(highScores).reduce((a, b) => a + b, 0);
  const currentGame = GAMES.find(g => g.id === gameType)!;

  const renderGame = () => {
    const props = {
      questions,
      onBack: () => setView('ANALYZE'),
      highScore: highScores[gameType],
      setHighScore: handleSetHighScore(gameType),
      difficulty
    };
    switch (gameType) {
      case 'SPACE': return <ArcadeGame {...props} />;
      case 'DINO': return <DinoGame {...props} />;
      case 'FLAPPY': return <FlappyBirdGame {...props} />;
      case 'SNAKE': return <SnakeGame {...props} />;
      case 'BREAKOUT': return <BreakoutGame {...props} />;
      case 'PONG': return <PongGame {...props} />;
      case 'TETRIS': return <TetrisGame {...props} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased selection:bg-indigo-500 selection:text-white">
      {/* Background decoration */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden select-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-500/10 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-amber-500/10 rounded-full blur-[120px]" />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-slate-800/80 bg-slate-900/50 backdrop-blur-md sticky top-0">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 select-none min-w-0">
            <div className="bg-gradient-to-br from-indigo-500 to-amber-500 p-1.5 rounded-lg shadow-lg shadow-indigo-500/20 shrink-0">
              <Gamepad2 className="w-5 h-5 text-slate-950 stroke-[2.5]" />
            </div>
            <div>
              <h1 className="text-sm font-black tracking-wide text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-300">
                EduPlay Arcade
              </h1>
              <p className="text-[9px] font-bold text-slate-500 tracking-wider uppercase">
                7 Oyun • Akıllı Soru Üretici
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="hidden sm:flex items-center gap-1.5 bg-slate-800/50 border border-slate-700/40 px-2.5 py-1 rounded-lg">
              <BookOpen className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-xs font-bold text-indigo-300">{questions.length}</span>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-800/50 border border-slate-700/40 px-2.5 py-1 rounded-lg">
              <Trophy className="w-3.5 h-3.5 text-amber-400" />
              <span className="text-xs font-bold text-amber-300">{totalHighScore}</span>
            </div>
            <button
              onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
              className="ml-2 flex items-center justify-center p-1.5 bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/40 rounded-lg transition-colors"
              title="Temayı Değiştir"
            >
              {theme === 'dark' ? (
                <Sun className="w-4 h-4 text-amber-400" />
              ) : (
                <Moon className="w-4 h-4 text-indigo-400" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Analyzer View */}
      {view === 'ANALYZE' && (
        <>
          {/* Game Picker */}
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-4 select-none">
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-7 gap-2">
              {GAMES.map(g => {
                const isSelected = gameType === g.id;
                return (
                  <button
                    key={g.id}
                    onClick={() => setGameType(g.id)}
                    className={`group flex flex-col items-center justify-center gap-1 p-2 rounded-xl border-2 transition-all active:scale-95 touch-manipulation min-h-[72px] cursor-pointer ${
                      isSelected
                        ? `bg-gradient-to-br ${GAME_COLORS[g.id]} border-white/30 shadow-lg text-white scale-105`
                        : 'bg-slate-900/40 border-slate-800 text-slate-400 hover:bg-slate-800/50 active:bg-slate-800/60'
                    }`}
                  >
                    <span className="text-xl sm:text-2xl leading-none transition-transform duration-300 group-hover:scale-125 group-hover:-translate-y-1 group-active:scale-90 inline-block">{g.emoji}</span>
                    <span className="text-[9px] sm:text-[10px] font-extrabold text-center leading-tight truncate w-full px-1">{g.name}</span>
                    {highScores[g.id] > 0 && (
                      <span className={`text-[8px] sm:text-[9px] font-mono px-1 rounded mt-0.5 ${isSelected ? 'bg-white/20 text-white' : 'bg-amber-500/20 text-amber-400'}`}>
                        {highScores[g.id]}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Quick Launch Button */}
          {questions.length > 0 && (
            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-3 select-none">
              <button
                onClick={() => setView('GAME')}
                className={`w-full bg-gradient-to-r ${GAME_COLORS[gameType]} hover:brightness-110 text-white font-black px-4 py-3 rounded-xl shadow-lg active:scale-[0.99] transition flex items-center justify-center gap-2`}
              >
                <Play className="w-4 h-4 fill-white" />
                <span>{currentGame.emoji} {currentGame.name}'na Başla</span>
                <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px] font-mono">{questions.length} Soru</span>
              </button>
            </div>
          )}

          <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 select-none">
            <FileAnalyzer
              questions={questions}
              setQuestions={setQuestions}
              onLaunchGame={() => setView('GAME')}
              difficulty={difficulty}
              setDifficulty={setDifficulty}
            />
          </main>
        </>
      )}

      {/* Game View */}
      {view === 'GAME' && (
        <main className="relative z-10 flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 select-none">
          {renderGame()}
        </main>
      )}

      {/* Footer */}
      <footer className="relative z-10 border-t border-slate-800/80 bg-slate-900/30 py-3 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex justify-between items-center text-[10px] text-slate-500">
          <span>© 2026 EduPlay Arcade</span>
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse"></span>
            7 Oyun Hazır
          </span>
        </div>
      </footer>
    </div>
  );
}
